from http.cookies import SimpleCookie
import json
import time
import urllib.request
from jose import jwk, jwt
from jose.utils import base64url_decode

region = 'ap-southeast-2'
userpool_id = 'ap-southeast-2_UPYkTiaKu'
app_client_id = '3q9hvump4v52gkt7517nk6i1t2'
keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(region, userpool_id)

with urllib.request.urlopen(keys_url) as f:
  response = f.read()
keys = json.loads(response.decode('utf-8'))['keys']


def get_auth_token_from_cookie(event):
    try:
        #cookie = SimpleCookie()
        #cookie.load(event["cookie"])
        headers=event.get("headers")
        cookie=headers.get("cookie")
        cookie_values = cookie.split("=")
        print(cookie_values[1])
        token = cookie_values[1]  # <- TOKEN is the name of the cookie
        return token
    except:
        print("Problem retrieving Token Cookie from request")
        print(event)
        raise Exception("Problem retrieving Token Cookie from request")


def generatePolicy(principalId, effect, methodArn):
    authResponse = {}
    authResponse["principalId"] = principalId
    base = methodArn.split("/")[0]
    stage = methodArn.split("/")[1]
    arn = base + "/" + stage + "/*/*"

    if effect and methodArn:
        policyDocument = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Sid": "FirstStatement",
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": arn,
                }
            ],
        }
        authResponse["policyDocument"] = policyDocument
        print(authResponse)
    return authResponse


def lambda_handler(event, context):
    MethodArn=event.get("methodArn")
    try:
        token = get_auth_token_from_cookie(event)
        headers = jwt.get_unverified_headers(token)
        kid = headers['kid']
        # search for the kid in the downloaded public keys
        key_index = -1
        for i in range(len(keys)):
            if kid == keys[i]['kid']:
                key_index = i
                break
        if key_index == -1:
            raise Exception('Public key not found in jwks.json')
        # construct the public key
        public_key = jwk.construct(keys[key_index])
        # get the last two sections of the token,
        # message and signature (encoded in base64)
        message, encoded_signature = str(token).rsplit('.', 1)
        # decode the signature
        decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
        # verify the signature
        if not public_key.verify(message.encode("utf8"), decoded_signature):
            raise Exception('Signature verification failed')
        print('Signature successfully verified')
        # since we passed the verification, we can now safely
        # use the unverified claims
        claims = jwt.get_unverified_claims(token)
        # additionally we can verify the token expiration
        if time.time() > claims['exp']:
            raise Exception('Token is expired')
        # and the Audience  (use claims['client_id'] if verifying an access token)
        if claims['aud'] != app_client_id:
            raise Exception('Token was not issued for this audience')
        # now we can use the claims
        print(claims)
        print(token)
        username_from_token = claims.get("sub")
        print(username_from_token)
        return generatePolicy(username_from_token, "Allow", MethodArn)
    except Exception as e:
        print(e)
        return generatePolicy(None, "Deny", MethodArn)