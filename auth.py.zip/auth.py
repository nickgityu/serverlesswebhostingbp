import base64
import os
from datetime import datetime, timedelta
import os.path
from typing import Tuple

# Declare defaults
CUSTOM_DOMAIN = "purelandexpedition.com"
CALLBACK_IDENTIFIER_PARAM = "callback"
LOGIN_URL = "https://static-web.auth.ap-southeast-2.amazoncognito.com/login?client_id=3q9hvump4v52gkt7517nk6i1t2&response_type=token&scope=email+openid+phone&redirect_uri=https://purelandexpedition.com?callback"
INDEX_FILE = "index.html"

DEBUG = True
def _log(msg: str):
    if DEBUG:
        print(msg)

def _get_path(event) -> str:
    path: str = event.get("path")
    if path == "/":
        path = f"/{INDEX_FILE}"
    return path

def _get_id_token_from_cookie(event) -> str:
    id_token: str = None
    headers = event.get("headers")
    if not headers is None:
        cookie = headers.get("Cookie")
        if not cookie is None:
            cookie_values = cookie.split("=")
            if len(cookie_values) == 2 and cookie_values[0] == "id_token":
                id_token = cookie_values[1]
    return id_token

def _get_id_token_and_expiry_from_body(event) -> Tuple[str, int]:
    is_post: bool = "httpMethod" in event and event.get("httpMethod") == "POST"
    has_body: bool = "body" in event
    expires_in: int = 60
    id_token: str = ""
    if is_post and has_body:
        base64body = event.get("body")
        print(f'this is the body {base64body}')
        #decoded_body:str = base64.b64decode(base64body).decode('utf-8')
        post_params_strings: list[str] = base64body.split("&")
        post_params: dict = {}
        for post_param_str in post_params_strings:
            key_val: list[str] = post_param_str.split("=")
            post_params[key_val[0]] = key_val[1]
        expires_in = post_params.get("expires_in")
        id_token = post_params.get("id_token")
        print(f'the id token is {id_token}')
    return (id_token, expires_in)

def _build_cookie_if_root_path(event, id_token, expires_in) -> str:
    path = _get_path(event)
    cookie: str = None
    if path ==  f"/{INDEX_FILE}":
        expires = (datetime.utcnow() + timedelta(milliseconds=3600)).strftime("%a, %d %b %Y %H:%M:%S GMT")
        cookie = f"id_token={id_token}; expires={expires}; path=/; domain=.{CUSTOM_DOMAIN}; SameSite=Strict"
    return cookie

def _build_response(event, id_token) -> dict:       
    expires_in: int = 1
    cookie = _build_cookie_if_root_path(event, id_token, expires_in)
    print(f'the cookie is {cookie}')
    response_value = {"statusCode": 302,  "headers": { "location": "/index.html"} }
    if not cookie is None:
        response_value["headers"]["Set-Cookie"] = cookie
    print(f'the response value is {response_value}')
    return response_value

def _is_login_callback(event):
    return "queryStringParameters" in event and \
    not event.get("queryStringParameters") is None \
    and CALLBACK_IDENTIFIER_PARAM in event.get("queryStringParameters")
    
def _build_id_token_post_form_response(event):
    response_value = { "body": """<html><body>
        </body>
        <script>
        var url = document.location.href.toString();
        var tokens = url.toString().split("#");
        if(tokens && tokens.length > 1){
            var params = tokens[1].split("&")
            if(params && params.length > 0){
                var frm = document.createElement("form");
        """ + f'frm.setAttribute("action", "https://{CUSTOM_DOMAIN}");' + """
                frm.setAttribute("method", "post");
                frm.setAttribute("hidden", "true");
                for(var i = 0; i < params.length; i++){
                    var keyValue = params[i].split("=");
                    if(keyValue && keyValue.length > 0){
                        var hdn = document.createElement("input");
                        hdn.setAttribute("type", "hidden");
                        hdn.setAttribute("name", keyValue[0]);
                        hdn.setAttribute("value", keyValue[1]);
                        frm.appendChild(hdn);
                    }
                }
                document.body.appendChild(frm);
                frm.submit();
            }
        }
        </script>
        </html>""", "headers": {"Content-Type": "text/html"} }
    print(response_value)
    return response_value
    
    
def _build_login_redirection_response(event):
    return {"statusCode": 302,  "headers": { "location": LOGIN_URL} }
    


def lambda_handler(event, context):

    id_token: str = _get_id_token_from_cookie(event)

    # Attempt to fetch id_token from POST
    if id_token is None:
        (id_token, expires_in) = _get_id_token_and_expiry_from_body(event)
        print(f'got id token from post {id_token}')
    
    # If id_token found validate claims prepare response
    if id_token:
        response_value = _build_response(event, id_token)
    
    elif _is_login_callback(event):
        response_value = _build_id_token_post_form_response(event)
    else:
        print('why here')
        response_value = _build_login_redirection_response(event)
    print(f'the final response is {response_value}')
    return response_value